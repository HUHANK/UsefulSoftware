import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class ExecSQL extends Thread{

	
	public static void main(String[] args) throws Exception {
//		for (int j=0; j<10; j++) {
//			ExecSQL execSQL = new ExecSQL();
//			execSQL.start();
//		}
		
		
		Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
        String url = "jdbc:db2://10.10.14.36:50000/KSDBS";
        String user = "back";
        String passwd = "back";
        Connection conn = DriverManager.getConnection(url, user, passwd);
        System.out.println("connection Done! OK!!!");
        
        Statement stmt = conn.createStatement();
        String sql = "INSERT INTO KS.ADDI_FUND("+
"ABNORMAL_FRZN_AMT,ACC_STATUS,ACCU_CHANGE_DATE,BRANCH_CODE,BUY_FROZEN_AMT,CASH_AMT,CASHORBILL,CBNT_FINE,CBNT_INTER_ACCU,CBNT_INTEREST,CHANGE_DATE,CHECK_AMT,CLOSE_DATE,CLOSE_EMP,CLOSE_TIME,CREDIT,CREDIT_END_DATE,CURRENCY_TYPE,CUST_NO,DEPOSIT,EVALUATE_ASSET,FALSE_BAIL,FINE,FINE_ACCU,FINE_ACCU_CHG_DATE,FORBID_AMT,FORBID_ASSET,FUND_ACC_NO,FUND_DEAL_METHOD,INTEREST,INTEREST_ACCU,LOAN_ACCU,LOAN_AMT,LOAN_INTEREST,MANUAL_FRZN_AMT,MANUAL_UNFRZN_AMT,MORTGAGE_AMT,OPEN_DATE,OPEN_EMP,OPEN_TIME,REAL_BUY_AMT,SELL_DONE_AMT,SPARE1,SPARE2,THIS_BAL,TOTAL_ASSET,UNCOME_BUY_AMT,UNCOME_SELL_AMT,WITHDRAW"+
") SELECT"+
"ABNORMAL_FRZN_AMT,ACC_STATUS,ACCU_CHANGE_DATE,BRANCH_CODE,BUY_FROZEN_AMT,CASH_AMT,CASHORBILL,CBNT_FINE,CBNT_INTER_ACCU,CBNT_INTEREST,CHANGE_DATE,CHECK_AMT,CLOSE_DATE,CLOSE_EMP,CLOSE_TIME,CREDIT,CREDIT_END_DATE,CURRENCY_TYPE,CUST_NO,DEPOSIT,EVALUATE_ASSET,FALSE_BAIL,FINE,FINE_ACCU,FINE_ACCU_CHG_DATE,FORBID_AMT,FORBID_ASSET,FUND_ACC_NO,FUND_DEAL_METHOD,INTEREST,INTEREST_ACCU,LOAN_ACCU,LOAN_AMT,LOAN_INTEREST,MANUAL_FRZN_AMT,MANUAL_UNFRZN_AMT,MORTGAGE_AMT,OPEN_DATE,OPEN_EMP,OPEN_TIME,REAL_BUY_AMT,SELL_DONE_AMT,SPARE1,SPARE2,THIS_BAL,TOTAL_ASSET,UNCOME_BUY_AMT,UNCOME_SELL_AMT,WITHDRAW"+
"FROM KS.FUND WHERE CUST_NO NOT IN (SELECT CUST_NO FROM KS.ADDI_FUND) FETCH FIRST 1000 ROWS ONLY";
        
        for(int i=0; i<10000; i++){
        	long t = System.currentTimeMillis();
        	stmt.execute(sql);
        	conn.commit();
        	t = System.currentTimeMillis()-t;
        	System.out.println("*   "+t);
        }

	}

	@Override
	public void run() {
		try{
			Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
	        String url = "jdbc:db2://10.10.14.36:50000/KSDBS";
	        String user = "back";
	        String passwd = "back";
	        Connection conn = DriverManager.getConnection(url, user, passwd);
	        System.out.println("connection Done! OK!!!");
	        
	        Statement stmt = conn.createStatement();
	        
	        for(int i=0; i<1000; i++){
	        	long t = System.currentTimeMillis();
	        	stmt.execute("DELETE FROM (SELECT * FROM KS.FUND FETCH FIRST 300 ROWS ONLY)");
	        	conn.commit();
	        	t = System.currentTimeMillis()-t;
	        	System.out.println("*   "+t);
	        }
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}
