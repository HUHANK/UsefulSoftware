import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

public class GetTableColumnName {

	public static void main(String[] args) throws Exception {
		Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
        String url = "jdbc:db2://10.10.13.23:50000/KSDBS";
        String user = "back2";
        String passwd = "back2";
        Connection conn = DriverManager.getConnection(url, user, passwd);
        System.out.println("connection Done! OK!!!");
        
        Statement stmt = conn.createStatement();
        String TABNAME = "FUND";
        String sql = "SELECT COLNAME, REMARKS FROM syscat.columns WHERE TABSCHEMA = 'KS' AND TABNAME = '"+TABNAME+"' ORDER BY COLNO";
        ResultSet rs = stmt.executeQuery(sql);
       
        BufferedWriter writer = new BufferedWriter(new FileWriter(new File("cols.csv")));
        int cols = rs.getMetaData().getColumnCount();
        while( rs.next() ){
        	String str = ""+rs.getString(1);
        	for( int i=2; i<=cols; i++ ){
        		str += ","+rs.getString(i);
        	}
        	System.out.println(str);
        	writer.write(str);
        	writer.newLine();
        }
        
        writer.close();
        stmt.close();
        conn.close();
	}

}
