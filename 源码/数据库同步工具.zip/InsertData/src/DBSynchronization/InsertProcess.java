package DBSynchronization;

import java.sql.SQLException;

public class InsertProcess extends Thread {

	public static int commit_count = 40;
	private static int ThreadNum = 0;
	
	public InsertProcess(){
		synchronized (this) {
			ThreadNum++;
		}
	}
	
	synchronized public boolean IExit(){
		--ThreadNum;
		if(ThreadNum == 0){
			return true;
		}else{
			return false;
		}
	}
	
	public void run(){
		DBConnect conn = new DBConnect(SyncServer.des_db_url, SyncServer.des_db_user, SyncServer.des_db_pwd);
	
		if( !conn.connect() )
			return ;
		
		try {
			conn.getConnect().setAutoCommit(false);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		DBQuery query = new DBQuery(conn);
		
		long count = 0;
		while( true ){
			count++;
			String sql = null;
			
			try {
				sql =  ProcessThread.m_insertQueue.take();
				//System.out.println( "SIZE: "+ProcessThread.m_insertQueue.size() );
			} catch (InterruptedException e) {
				e.printStackTrace();
				continue;
			}
			/*�˳�*/
			if( sql.equalsIgnoreCase("EXIT") ){
				try {
					conn.getConnect().commit();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;
			}
			
			/*ִ��SQL���*/
			try {
				query.execute(sql);
			} catch (SQLException e) {
				System.out.println(sql);
				e.printStackTrace();
			}
			if( count%commit_count == 0 ){
				try {
					conn.getConnect().commit();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				LogThread.log("-");
			}
		}
		System.out.println("@�߳� ["+getId()+"] �˳�");
		if( IExit() ){
			LogThread.Stop();
			LogThread.log("Exit!");
		}
	}
}
