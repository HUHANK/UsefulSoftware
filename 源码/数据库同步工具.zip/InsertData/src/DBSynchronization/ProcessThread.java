package DBSynchronization;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ProcessThread extends Thread{

	public static BlockingQueue<String> m_insertQueue = 
			new ArrayBlockingQueue<String>(1000);
	
	public static int AliveThreadNum = 0;
	public static int NeedTruncateBeforeInsert = 0;
	
	public ProcessThread(){
		synchronized (this) {
			AliveThreadNum++;
		}
	}
	
	public void run(){
		long COUNT = 0;
		while( true ){
			/*��ȡ����Ҫ�����ı���*/
			String TableName = null;
			try {
				TableName = SyncServer.m_queue.take();
			} catch (InterruptedException e) {
				e.printStackTrace();
				System.exit(-1);
			}
			if( TableName.equalsIgnoreCase("EXIT") ){
				synchronized (this) {
					AliveThreadNum--;
				}
				break;
			}
			
			String[] ss = TableName.split("&", 2);
			String sWhere = "";
			if (ss.length < 2) TableName = ss[0];
			else {
				TableName = ss[0];
				sWhere = ss[1];
			}
			System.out.println();
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.println("Now Process Table ��"+TableName+"��......");
			
			/*��ȡ�ñ��������ֺ�����,�������insert��SQL���*/
			String sql = "select COLNAME,TYPENAME from syscat.columns where TABSCHEMA='KS' and TABNAME='"+TableName+"'";
			DBQuery source_query = new DBQuery(SyncServer.source_db_conn);
			DBQuery dest_query = new DBQuery(SyncServer.dest_db_conn);
			
			if (NeedTruncateBeforeInsert != 0) {
				sWhere = sWhere.trim();
				System.out.println("���ڿ�ʼɾ������"+TableName+"��������...");
				try {
					//dest_query.execute("DELETE FROM "+TableName);
					if (sWhere.equals("") || sWhere.isEmpty()) {
						System.out.println("TRUNCATE TABLE "+TableName);
						dest_query.execute("TRUNCATE TABLE "+TableName+" IMMEDIATE");
					}
					else {
						System.out.println("DELETE TABLE "+TableName);
						dest_query.execute("DELETE FROM "+TableName+" "+sWhere);
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				System.out.println("����"+TableName+"������ɾ�����!");
			}
			
			Vector<Vector<Object>> ret = source_query.query(sql);
			String PreInsert = "INSERT INTO "+TableName+"(";
			for(int i=2; i<ret.size(); ++i ){
				PreInsert += (String)ret.get(i).get(0)+ ",";
			}
			int index = PreInsert.lastIndexOf(",");
			PreInsert = PreInsert.substring(0, index);
			PreInsert += ") VALUES(";
			
			int LOG_NUM = 0;
			/*��ȡ������,�û����SQL���*/
			sql = "select * from "+TableName + " " + sWhere;
			sql = sql.trim();
			try {
				Statement stmt = SyncServer.source_db_conn.getConnect().createStatement();
				ResultSet rSet = stmt.executeQuery(sql);
				while( rSet.next() ){
					try{
						if ((LOG_NUM++)%20 == 0)	LogThread.log("*");
						String insert = PreInsert;
						for( int i=2; i<ret.size(); ++i ){
							String ColumnName = (String)ret.get(i).get(0);
							String ColumnType = (String)ret.get(i).get(1);
							String sValue = "";
							if( ColumnType.contains("CHAR") ){
								String strT = rSet.getString(ColumnName);
								strT = strT.replaceAll("'", "''");
								sValue+= "'"+strT+"'";
							}else if( ColumnType.contains("INT") ){
								sValue+= rSet.getInt(ColumnName);
							}else if( ColumnType.contains("DECIMAL") ){
								sValue+= rSet.getBigDecimal(ColumnName);
							}else if( ColumnType.contains("TIMESTAMP") ){
								sValue += "'"+rSet.getTimestamp(ColumnName).toString()+"'";
							}
							insert += sValue + ",";
						}
					
						index = insert.lastIndexOf(",");
						insert = insert.substring(0, index);
						insert += ")";
						//System.out.println(insert);
						m_insertQueue.put(insert);
					}catch (Exception e) {
						e.printStackTrace();
					}
				}
				rSet.close();
				stmt.close();
			} catch ( Exception e ) {
				e.printStackTrace();
			}
			
		}
		//����ѭ��֮����������
		boolean btemp = false;
		synchronized (this) {
			if( AliveThreadNum == 0 ){
				btemp = true;
			}
		}
		
		if( btemp ){
			for( int i=0; i<(SyncServer.SecondLevelThreadNum*2); i++ ){
				try {
					m_insertQueue.put("EXIT");
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		
		System.out.println("@�߳� ["+getId()+"] �˳�");
	}
	
}
