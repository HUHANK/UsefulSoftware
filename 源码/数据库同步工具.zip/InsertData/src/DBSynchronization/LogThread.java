package DBSynchronization;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class LogThread extends Thread {

	static BlockingQueue<String>  m_queue = new ArrayBlockingQueue<String>(1000);
	
	public final static int INFO = 0;
	public final static int DEBUG = 1;
	public final static int ERROR = 2;
	public static	boolean canStop = false;
	
	public LogThread(){
		
	}
	
	public static void Stop(){
		canStop = true;
	}
	
	synchronized public static void log(String msg) {
		try {
				m_queue.put(msg);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void run(){
		long COUNT = 0;
		while(true){
			if( canStop )
				break;
			
			String msg = "";
			try {
				msg=m_queue.take();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.print(msg);
			COUNT++;
			if( COUNT%150 == 0 ){
				System.out.println();
			}
		}
	}
	
}
