package DBSynchronization;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Vector;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class SyncServer {
	
	// ��׼�� 23
	/*
	public static String src_db_url = "jdbc:db2://10.10.13.23:50000/KSDBS:currentSchema=KS;";
	public static String src_db_user = "back2";
	public static String src_db_pwd = "back2";
	*/
	public static String src_db_url = null;
	public static String src_db_user = null;
	public static String src_db_pwd = null;
	
	// 192��
	/*
	public static String src_db_url = "jdbc:db2://10.10.12.192:50000/KSDBS:currentSchema=KS;";
	public static String src_db_user = "back";
	public static String src_db_pwd = "back";
	*/
	// 36��
	public static String des_db_url = null;
	public static String des_db_user = null;
	public static String des_db_pwd = null;
	
	public static DBConnect source_db_conn = null;
	public static DBConnect dest_db_conn = null;
	public static BlockingQueue<String> m_queue =  new ArrayBlockingQueue<String>(20);
	
	/*0 - ȫ��ͬ��; 1 - ��ȡ�����ļ���ͬ��*/
	public static int SyncMode = 1; 
	
	public static  String AppointFile = null;
	public static  int	FirstLevelThreadNum = 1; //һ�������̸߳���
	public static  int SecondLevelThreadNum = 100;	//���������̸߳���
	
	/* �����ļ���   */
	private final static String config_file = "Sync.cnf";
	
	Vector<String> m_source_tables = new Vector<String>();
	Vector<String> m_dest_tables = new Vector<String>();
	Vector<String> m_apoint_tables = new Vector<String>();
	
	public SyncServer() throws Exception{
		
		SynConfigRead conf = new SynConfigRead(config_file);
		SyncMode = Integer.parseInt(conf.get("BASIC", "Sync_Mode"));
		if (0 == SyncMode) System.out.println("���ݿ�ͬ����ʽ: 0-ȫ��ͬ��");
		else if (1 == SyncMode) System.out.println("���ݿ�ͬ����ʽ: 1-����ͬ��");
		
		AppointFile = conf.get("Basic", "syn_file");
		System.out.println("ͬ�������ļ�·���� "+AppointFile);
		
		FirstLevelThreadNum = Integer.parseInt(conf.get("basic", "FIRST_LEVEL_PROCESS_THREADS"));
		SecondLevelThreadNum = Integer.parseInt(conf.get("basic", "SECOND_LEVEL_PROCESS_THREADS"));
		System.out.println("һ�����ݴ����߳�����: "+FirstLevelThreadNum);
		System.out.println("�������ݴ����߳�����: "+SecondLevelThreadNum);

		src_db_url = conf.get("SRC_DB", "url");
		src_db_user = conf.get("SRC_DB", "user");
		src_db_pwd = conf.get("SRC_DB", "pwd");
		System.out.println("��ͬ��Դ���ݿ����á�");
		System.out.println("URL: "+src_db_url);
		System.out.println("USER: "+src_db_user);
		
		des_db_url = conf.get("DES_DB", "url");
		des_db_user = conf.get("DES_DB", "user");
		des_db_pwd = conf.get("DES_DB", "pwd");
		System.out.println("����ͬ�����ݿ����á�");
		System.out.println("URL: "+des_db_url);
		System.out.println("USER: "+des_db_user);
		
		/*��ȡ�Ƿ���Ҫ�ڲ����֮ǰɾ�������ݵ�����*/
		ProcessThread.NeedTruncateBeforeInsert = 
				Integer.parseInt(conf.get("BASIC", "NEED_TRUNCATE").trim());
		/*��ȡinsert������commit�Ĵ���*/
		InsertProcess.commit_count = 
				Integer.parseInt(conf.get("BASIC", "COMMIT_NUM").trim());
		
		{
			System.out.println();
			System.out.print("��ȷ���������á�Y:ȷ��/N:ȡ����");
			char i = (char) System.in.read();
			if (('Y' == i) || ('y' == i)) System.out.println("��ʼ��������ͬ��......");
			else if (('N' == i) || ('n' == i)) {System.out.println("���������");System.exit(0);}
			else {System.out.println("���������");System.exit(0);}
		}
		
		source_db_conn = new DBConnect( src_db_url, src_db_user, src_db_pwd );
		dest_db_conn = new DBConnect( des_db_url, des_db_user, des_db_pwd );
		
		if( !source_db_conn.connect() )
			throw new Exception("ERROR");
		if( !dest_db_conn.connect() )
			throw new Exception("ERROR");
		
	}
	
	public void GetSrcAndDestTables(){
		DBQuery source_query = new DBQuery(source_db_conn);
		DBQuery dest_query = new DBQuery(dest_db_conn);
		String sql = "select TABNAME from syscat.tables where TABSCHEMA='KS' and TYPE='T'";
		
		Vector<Vector<Object>> ret = source_query.query(sql);
		for(int i=2; i<ret.size(); i++){
			m_source_tables.add( (String) ret.get(i).get(0) );
		}
		
		ret = dest_query.query( sql );
		for(int i=2; i<ret.size(); i++ ){
			m_dest_tables.add((String) ret.get(i).get(0) ); 
		}
	}
	
	public void SyncAllTables(){	/*ȫ��ͬ��*/
		GetSrcAndDestTables();
		for(int i=0; i<m_dest_tables.size(); ++i ){
			String TableName = m_dest_tables.get(i);
			
			if( !m_source_tables.contains(TableName) ){
				System.out.println("Դ���ݿ�����û�иñ�,����....");
				//System.exit(-1);
				continue;
			}
			try {
				m_queue.put(TableName);
			} catch (InterruptedException e) {
				e.printStackTrace();
				--i;
			}
		}
	}
	
	public void ReadSyncTables(){  /*��ȡͬ�����ñ��ļ�*/
		try {
			FileInputStream in = new FileInputStream(AppointFile);
			InputStreamReader inReader = new InputStreamReader(in, "UTF-8");
			BufferedReader br = new BufferedReader(inReader);
			String line = null;
			
			while( (line = br.readLine())!= null ){
				if (line.isEmpty())	continue;
				if (line.trim() == "")	continue;
				if (line.trim().charAt(0) == '#') continue;
				m_apoint_tables.add(line.trim());
			}
			br.close();
			inReader.close();
			in.close();
		} catch ( Exception e ) {
			e.printStackTrace();
		}
	}
	
	public void SyncAppointTables(){ /*���������ļ���ͬ��ԭʼ���Ŀ���*/
		GetSrcAndDestTables();
		ReadSyncTables();
		
		for( int i=0; i<m_apoint_tables.size(); ++i ){
			String line = m_apoint_tables.get(i);
			String ss[] = line.split("&", 2);
			String TableName = null;
			String sWhere = "";
			if (ss.length < 2)	TableName = ss[0];
			else {
				TableName = ss[0].trim();
				sWhere = ss[1].trim();
			}
			
			TableName = TableName.toUpperCase();
			if( !m_dest_tables.contains(TableName) ){
				System.out.println("Ŀ�����ݿ���û�б�: "+TableName);
				continue;
			}
			if( !m_source_tables.contains(TableName) ){
				System.out.println("ԭʼ���ݿ���û�б�: "+TableName);
				continue;
			}
			
			try {
				m_queue.put(TableName+"&"+sWhere);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void process(){
		if( 0 == SyncMode ){
			SyncAllTables();
		}else if( 1 == SyncMode ){
			SyncAppointTables();
		}
		
		/*֪ͨ���̱߳������������,�����˳�*/
		for(int i=0; i<(FirstLevelThreadNum*2); i++ ){
			try{
				m_queue.put("EXIT");
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args) {
		SyncServer server = null;
		
		try {
			server = new SyncServer();
		} catch (Exception e1) {
			e1.printStackTrace();
			return;
		}
		
		LogThread logThread = new LogThread();
		logThread.start();
		
		for( int i=0; i<SecondLevelThreadNum; i++ ){
			InsertProcess th2 = new InsertProcess();
			th2.start();
		}
		for( int i=0; i<FirstLevelThreadNum; i++ ){
			ProcessThread th1 = new ProcessThread();
			th1.start();
		}
		
		try {
			server.process();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("@���߳��˳�");
	}

}
