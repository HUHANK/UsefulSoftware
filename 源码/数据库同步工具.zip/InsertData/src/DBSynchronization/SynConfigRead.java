package DBSynchronization;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class SynConfigRead {
	//�����ļ�����
	private String FileName = null;
	private static final String split_regex = "=";
	
	private Map<String, Map<String, String>> m_config = 
			new HashMap<String, Map<String, String>>();
	
	public SynConfigRead() {};
	public SynConfigRead(String fileName) throws Exception {
		FileName = fileName;
		process();
	}
	
	public String get(String firstKey, String SecondKey) {
		Map<String, String> conf = m_config.get(firstKey.toUpperCase());
		if (null == conf) {
			System.out.println("�޷���ȡ"+firstKey+" ��ص�������Ϣ");
			return null;
		}
		return conf.get(SecondKey.toUpperCase());
	}
	
	private void process() throws Exception {
		FileInputStream in = new FileInputStream(FileName);
		InputStreamReader inReader = new InputStreamReader(in);
		BufferedReader br = new BufferedReader(inReader);
		String line = null;
		
		String confS = null;
		Map<String, String> confM = null;
		
		while ((line = br.readLine()) != null) {
			line = line.trim();
			if (line.isEmpty()) continue;
			if (line == "") continue;
			else if (line.charAt(0) == '#') continue;
			else if (line.charAt(0) == '/' && line.charAt(1) == '/') continue;
			
			/* ����   [ ˵��������һ��һ���ڵ�   */
			if ('[' == line.charAt(0)) {
				if (confM == null) {
					confS = null;
					confM = new HashMap<String, String>();
				} else {
					m_config.put(confS, confM);
					confM = new HashMap<String, String>();
					confS = null;
				}
				
				line = line.replace("[", "").replace("]", "");
				confS = line.trim().toUpperCase();
			} else { /* ���������ڵ����� */
				String[] arr = line.split(split_regex, 2);
				if (arr.length != 2) {
					System.err.println("�����ļ�������һ���������飡");
					continue;
				}
				String key = arr[0].trim().toUpperCase();
				String value = arr[1].trim();
				confM.put(key, value);
			}
		}
		if (null != confM) {
			m_config.put(confS, confM);
		}
		
		br.close();
		inReader.close();
		in.close();
	}
	
}
