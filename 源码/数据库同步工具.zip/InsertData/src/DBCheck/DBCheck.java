package DBCheck;

import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import DBSynchronization.DBConnect;
import DBSynchronization.DBQuery;

/*���Ա��������ݿ��״̬,�������Ƿ�һ��,���ṹ�Ƿ�һ��...*/

public class DBCheck {
	
	public static String sourceDBUrl = "jdbc:db2://10.10.13.23:50000/KSDBS:currentSchema=KS;";
	//public static String sourceDBUrl = "jdbc:db2://10.10.12.192:50000/KSDBS:currentSchema=KS;";
	public static String destDBUrl = "jdbc:db2://10.10.14.37:50000/KSDBS:currentSchema=KS;";
	public static DBConnect source_db_conn = null;
	public static DBConnect dest_db_conn = null;
	
	public Vector<String> m_src_tables = new Vector<String>();
	public Vector<String> m_des_tables = new Vector<String>();
	public Vector<String> m_dif_tables = new Vector<String>(); 
	
	public DBCheck() throws Exception {
		source_db_conn = new DBConnect(sourceDBUrl, "back2", "back2");
		dest_db_conn = new DBConnect(destDBUrl, "back", "back");
		if( !source_db_conn.connect() )
			throw new Exception("");
		if( !dest_db_conn.connect() )
			throw new Exception("");
	}
	
	public void check_tables(){
		DBQuery src_query = new DBQuery(source_db_conn);
		DBQuery des_query = new DBQuery(dest_db_conn);
		String sql = "select TABNAME from syscat.tables where TABSCHEMA='KS' and TYPE='T'";
		
		Vector<Vector<Object>> ret = src_query.query(sql);
		for( int i=2; i<ret.size(); i++ ){
			m_src_tables.add((String) ret.get(i).get(0) );
		}
		ret = des_query.query(sql);
		for( int i=2; i<ret.size(); i++ ){
			m_des_tables.add((String) ret.get(i).get(0) );
		}
		
		for( int i=0; i<m_src_tables.size(); i++ ){
			String TableName = m_src_tables.get(i);
			if( !m_des_tables.contains(TableName) ){
				m_dif_tables.add(TableName);
			}
		}
		
		System.out.println("Ŀ�����ݿ���Ƿȱ�ı���������ʾ:");
		for( int i=0; i<m_dif_tables.size(); i++ ){
			String TableName = m_dif_tables.get(i);
			System.out.println("\t"+(i+1)+"\t"+TableName);
		}
		System.out.println("Ŀ�����ݿ����ܹ�Ƿȱ�����ݱ�����: "+m_dif_tables.size());
	}
	
	public void check_columns(){
		DBQuery src_query = new DBQuery(source_db_conn);
		DBQuery des_query = new DBQuery(dest_db_conn);
		
		for( int j=0; j<m_src_tables.size(); j++ ){
			String TableName = m_src_tables.get(j);
			if( !m_des_tables.contains(TableName) )
				continue;
			
			String sql = "select COLNAME,TYPENAME from syscat.columns where TABSCHEMA='KS' and TABNAME='"+TableName+"'";
			Vector<Vector<Object>> src_ret = src_query.query(sql);
			Vector<Vector<Object>> des_ret = des_query.query(sql);
			
			/*���ݸ�ʽת��,�������ıȽϺ���ʾ*/
			Map<String, String> m_src_ret = new HashMap<String, String>();
			Map<String, String> m_des_ret = new HashMap<String, String>();
			
			for( int i=2; i<src_ret.size(); i++ ){
				m_src_ret.put((String)src_ret.get(i).get(0), (String)src_ret.get(i).get(1));
			}
			for( int i=2; i<des_ret.size(); i++ ){
				m_des_ret.put( (String)des_ret.get(i).get(0), (String)des_ret.get(i).get(1));
			}
			
			/*�ȱȽϸ���,���������ͬ,����ṹ�϶���һ��*/
			boolean needShowDif = false;
			if( src_ret.size() == des_ret.size() ){
				/*������column�ȶ�*/
				for( String key : m_src_ret.keySet() ){
					if( !m_des_ret.containsKey(key) ){
						needShowDif = true;
						break;
					}
				}
			}else{
				needShowDif = true;
			}
			
			if( !needShowDif )
				continue;
			
			/*��ʾ*/
			System.out.println();
			System.out.println("@TableName: "+TableName);
			System.out.printf("%30s%30s\n","SourceTable", "DestTable");
			for( String key : m_src_ret.keySet() ){
				System.out.printf("%20s%20s", key, m_src_ret.get(key) );
				if( m_des_ret.containsKey(key) ){
					System.out.printf("%20s%20s", key, m_des_ret.get(key) );
				}else{
					System.out.printf("%20s%20s", "**", "**");
				}
				System.out.println();
			}
			for( String key : m_des_ret.keySet() ){
				if( !m_src_ret.containsKey(key) ){
					System.out.printf("%20s%20s%20s%20s", "**","**",key, m_des_ret.get(key));
				}
				System.out.println();
			}
		}
	}
	
	public static void main(String[] args) {
		try {
			DBCheck check = new DBCheck();
			check.check_tables();
			
			check.check_columns();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
