
import java.sql.*;

/**
 * Created by hepeng on 2016/11/18: 16:31
 */
public class ImportData {
    static  String genStr( int leng ){
        String res = "";
        for( int i=0; i<leng; i++ ){
        	res += ((int)(Math.random()*100000))%10;
        }
        return res;
    }
    
    static void test1(Connection conn) throws Exception{
    	String sql = "insert into KS.FRZN_STATS_CFG(	BUSINESS_CODE,	MARKT_CODE,	GATHER_SOURCE,	FUND_FLAG, "
    			+ "UNFRZN_FUND_ITEM, FRZN_FUND_ITEM, CREATE_DATE, "
    			+ "CREATE_USER, UPDATE_DATE, UPDATE_USER"
    			+ ") values(?,?,?,?,  ?,?,?,?,  ?,?)";
        PreparedStatement ps = conn.prepareStatement(sql);
    	conn.setAutoCommit(false);
    	
    	for( int n=0; n< 5000 ; ++n){
    		long t1 = System.currentTimeMillis();
	        for( int i=0; i< 1; i++ ){
	        	ps.setString(1, genStr(4));
	        	ps.setString(2, genStr(1));
	        	ps.setString(3, genStr(1));
	        	ps.setString(4, genStr(1));
	        	
	        	ps.setInt(5, 1);
	        	ps.setInt(6, 1);
	        	ps.setInt(7, 13200400);
	        	ps.setString(8, "test");
	        	
	        	ps.setInt(9, 123234322);
	        	ps.setString(10, "test");
	        	
	        	ps.addBatch();
	        }
	        ps.executeBatch();
	        conn.commit();
	        float ti = ((float)(System.currentTimeMillis()-t1))/1000;
	        System.out.println((n+1)+"\t*****["+ti+"]*******");
    	}
    }

    public static void main(String args[]) throws Exception{

        Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
        String url = "jdbc:db2://10.10.12.192:50000/KSDBS";
        String user = "back";
        String passwd = "back";
        Connection conn = DriverManager.getConnection(url, user, passwd);
        System.out.println("connection Done! OK!!!");
        /*
        Statement statement = conn.createStatement();
        String sql = "import from /dev/null of del replace into KS.HIS_FUND_SUN";
        System.out.println( statement.execute(sql) );*/
        
        long startT = System.currentTimeMillis();
        for( int ii =0; ii<10000; ii++ ){
	        try{
	        	test1(conn);
	        }catch (Exception e) {
				e.printStackTrace();
			}
        }
        System.out.println( "�ܹ���ʱ ��"+((System.currentTimeMillis()-startT)/(float)1000) );

    }
}
