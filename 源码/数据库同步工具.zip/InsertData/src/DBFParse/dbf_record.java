package DBFParse;

import java.io.IOException;

public class dbf_record {

	public String	field_name = null;
	public char		field_type = 0;
	public int		field_offset = 0;
	
	public short 	field_len = 0;
	public short	accuracy = 0;
	
	public short	reserve = 0;
	public short	work_id = 0;
	public String	msg = null;
	
	public char		mdx = 0;
	
	public final static short SIZE = 32;
	
	public dbf_record () {};
	
	public void test () {
		System.out.println("field_name\t"+field_name);
		System.out.println("field_type\t"+field_type);
		System.out.println("field_offset\t"+field_offset);
		System.out.println("field_len\t"+field_len);
		System.out.println("accuracy\t"+accuracy);
		System.out.println("work_id\t"+work_id);
	}
	
	public boolean init( bFile file ) {
		boolean ret = true;
		
		try {
			field_name = new String( file.read(11) );
			field_type = (char) file.read(1)[0];
			field_offset = file.IntByteOrderTrans( file.byteArrayToInt( file.read(4) ) );
			
			field_len = (short) file.read(1)[0] ;
			accuracy = file.read(1)[0] ;
			reserve  = file.ShortByteOrderTrans( file.byteArrayToShort( file.read(2) ) );
			work_id = file.read(1)[0] ;
			
			msg = new String( file.read(10) );
			mdx = (char) file.read(1)[0] ;
			
		} catch (IOException e) {
			ret = false;
			e.printStackTrace();
		}
		test();
		return ret;
	}
	
	public Object getValue( bFile file ) {
		try {
			byte[] b = file.read(field_len);
			switch (field_type) {
			case 'C':
			case 'D':
				return new String(b);
			case 'N':
				return new String(b);
			default:
				break;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
