package DBFParse;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class bFile {

	private BufferedInputStream bis = null;
	
	public  bFile(String fileName) throws FileNotFoundException {
		File f = new File(fileName);
		bis = new BufferedInputStream(new FileInputStream(f));
	}
	
	public byte[] read(int n) throws IOException {
		byte[] ret = new byte[n];
		
		bis.read(ret);
		
		return ret;
	}
	
	public int IntByteOrderTrans ( int value ) {
		int ret = 0;
		byte[] b = new byte[4];
		
		for (int i=0; i<4; ++i) {
			b[i] = (byte) (value >> (i*8) & 0xff);
		}
		
		ret = (b[3] & 0xff) | ((b[2] & 0xff) << 8) | ((b[1] & 0xff) << 16) | ((b[0] & 0xff) << 24) ; 
		
		return ret;
	}
	
	public short ShortByteOrderTrans(short value) {
		byte low = (byte) (value & 0xff);
		byte hight = (byte) ((value >> 8) & 0xff);
		return (short) ((hight ) | (low << 8));
	}
	
	public int byteArrayToInt( byte[] b ) {
		int i = 3;
		return (b[i--] & 0xFF) << 0 |
				 (b[i--] & 0xFF) << 8 |
				 (b[i--] & 0xFF) << 16 |
				 (b[i--] & 0xFF) << 24 ;
	}
	
	public short byteArrayToShort( byte[] b ) {
		int i = 1;
		return (short)((b[i--] & 0xFF) << 0 | (b[i--] & 0xFF) << 8);
				
	}
	
	public static void main(String[] args) {
		try {
			bFile file = new bFile("C:/Users/admin/Desktop/�Ǽǽ���/��������/SJSDZ0213.DBF");
			dbf_header header = new dbf_header();
			header.init(file);
			
			int n = (header.header_length - dbf_header.SIZE) / dbf_record.SIZE;
			dbf_record [] records = new dbf_record[n];
			for (int i=0; i<n; ++i) {
				records[i] = new dbf_record();
				records[i].init(file);
			}
			
			long max = header.records;
			for(long i=0; i<max; ++i) {
				System.out.println(i+1);
				file.read(1);
				for(int j=0; j<n; j++) {
					System.out.print(records[j].getValue(file)+"\t");
				}
				System.out.println();
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
