package DBFParse;

import java.io.IOException;

public class dbf_header {
	
	public short version = 0;		//1
	public short update_year = 0;	//1
	public short update_month = 0;	//1
	public short update_day = 0;	//1
	
	public long records = 0;		//4
	public short header_length = 0;	//2
	public short record_length = 0;	//2
	public long user_argument = 0;	//4
	public String reserve = null;	//16
									//�ܼ�32���ֽ�
	
	public final static short SIZE = 32;
	
	public dbf_header () {};
	
	public void test() {
		System.out.println("version\t"+version);
		System.out.println("update_year\t"+update_year);
		System.out.println("update_month\t"+update_month);
		System.out.println("update_day\t"+update_day);
		System.out.println("records\t"+records);
		System.out.println("header_length\t"+header_length);
		System.out.println("record_length\t"+record_length);
		System.out.println("user_argument\t"+user_argument);
		System.out.println("reserve\t"+reserve);
	}
	
	public boolean init( bFile bf ) {
		boolean ret = true;

		try {
			version = (short) (bf.read(1)[0] & 0xff);
			update_year = (short) (bf.read(1)[0] & 0xff);
			update_month = (short) (bf.read(1)[0] & 0xff);
			update_day = (short) (bf.read(1)[0] & 0xff);
			
			records = bf.IntByteOrderTrans( bf.byteArrayToInt(bf.read(4)) );
			header_length = bf.ShortByteOrderTrans( bf.byteArrayToShort(bf.read(2)) );
			record_length = bf.ShortByteOrderTrans( bf.byteArrayToShort(bf.read(2)) );
			
			user_argument = bf.byteArrayToInt(bf.read(4));
			reserve = new String( bf.read(16) );
			
		} catch (IOException e) {
			ret = false;
			e.printStackTrace();
		}
		test();
		return ret;
	}
	
}
