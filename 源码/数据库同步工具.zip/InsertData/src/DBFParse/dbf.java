package DBFParse;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;


public class dbf {

	public static void main(String[] args) throws Exception {
		
		File f = new File("C:/Users/admin/Desktop/�Ǽǽ���/��������/SJSDZ0213.DBF");
		BufferedInputStream bis = new BufferedInputStream(new FileInputStream(f));
		
		
		
	}

}
