package PiQianDuiZhang;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
import java.util.Vector;

import DBSynchronization.DBConnect;


enum NEQUAL_TYPE{
	NEQUAL_TYPE_ALL_EQUAL("ȫƽ", 0),
	NEQUAL_TYPE_NOT_SYSTEM_RECORDS("�Ǳ�ϵͳ����", 1),
	NEQUAL_TYPE_NEARLY_EQUAL("����ƽ,�����ò�ƽ", 2),
	NEQUAL_TYPE_AMT_NOT_EQUAL("��ƽ", 3),
	NEQUAL_TYPE_VOL_NOT_EQUAL("������ƽ", 4),
	NEQUAL_TYPE_AMT_VOL_NOT_EQUAL("����������ƽ", 5);
	
	private String name;
	private int index;
	
	private NEQUAL_TYPE(String name, int index ){
		this.name = name;
		this.index = index;
	}
	
	public String str(){
		return name;
	}
	
	public int num(){
		return index;
	}
	
};

public class PQDZServer {
	public DBConnect conn = null;

	public Vector<BUSI_CMP_RESULT> vcmp_result = new Vector<BUSI_CMP_RESULT>();
	public BUSI_CMP_CFG  busi_cmp_cfg = new BUSI_CMP_CFG();
	BUSI_CMP_RESULT_set result_set = null;
	
	public void getResultSet(String sqll) throws Exception {
		Connection connection = conn.getConnect();
		Statement stmt = connection.createStatement();
		ResultSet rSet = stmt.executeQuery(sqll);
		
		while( rSet.next() )
		{
			BUSI_CMP_RESULT result = new BUSI_CMP_RESULT();
			result.smarket_code = 	rSet.getString("MARKET_CODE").trim();
			result.sseat_no = 		rSet.getString("DONE_SEAT").trim();
			result.sbusiness_code = rSet.getString("BUSINESS_CODE").trim();
			result.ssec_type = 		rSet.getString("SEC_TYPE").trim();
			result.ssec_code = 		rSet.getString("SEC_CODE").trim();
			result.sin_out = 		rSet.getString("IN_OUT").trim();
			result.ssec_in_out = 	rSet.getString("SEC_IN_OUT").trim();
			result.ddone_amt = 		rSet.getBigDecimal("DONE_AMT").doubleValue();
			result.ddone_vol = 		rSet.getBigDecimal("DONE_VOL").doubleValue();
			result.dstamp_tax = 	rSet.getBigDecimal("STAMP_TAX_COL").doubleValue();
			result.dchg_owner_fee = rSet.getBigDecimal("CHG_OWNER_FEE").doubleValue();
			
			System.out.println("SEC_CODE: "+result.ssec_code);
			
			BUSI_CMP_RESULT tmp = result_set.Find(result);
			
			if( busi_cmp_cfg.sec_type.equals("") ){
			}else{
				result.ssec_type = busi_cmp_cfg.sec_type;
			}
			//����
			{
				if( busi_cmp_cfg.idata_source_type == 1 ){
					if( result.ssec_in_out.length()>0 && result.ssec_in_out.charAt(0) == 'B' ){
						tmp.dfirst_buy_vol += result.ddone_vol;
					}else if ( result.ssec_in_out.length()>0 && result.ssec_in_out.charAt(0) == ('S') ){
						tmp.dfirst_sell_vol += result.ddone_vol;
					}else if( busi_cmp_cfg.fund_sec_direction.charAt(1) == ('1') ){
						tmp.dfirst_buy_vol += result.ddone_vol;
					}else if( busi_cmp_cfg.fund_sec_direction.charAt(1) == ('0') ){
						tmp.dfirst_sell_vol += result.ddone_vol;
					}
				}else{
					if( result.ssec_in_out.length()>0 && result.ssec_in_out.charAt(0) == 'B' ){
						tmp.dsecond_buy_vol += result.ddone_vol;
					}else if( result.ssec_in_out.length()>0 && result.ssec_in_out.charAt(0) == ('S') ){
						tmp.dsecond_sell_vol += result.ddone_vol;
					}else if( busi_cmp_cfg.fund_sec_direction.charAt(1) == ('1') ){
						tmp.dsecond_buy_vol += result.ddone_vol;
					}else if( busi_cmp_cfg.fund_sec_direction.charAt(1) == ('0') ){
						tmp.dsecond_sell_vol += result.ddone_vol;
					}
				}
			}
			//���
			{
				if( busi_cmp_cfg.idata_source_type == 1 ){
					if(result.sin_out.length()>0 && result.sin_out.charAt(0) == '1' ){
						tmp.dfirst_sell_amt += result.ddone_amt;
					}else if( result.sin_out.length()>0 && result.sin_out.charAt(0) == '0' ){
						tmp.dfirst_buy_amt += result.ddone_amt;
					}else if( busi_cmp_cfg.fund_sec_direction.charAt(0) == '1' ){
						tmp.dfirst_sell_amt += result.ddone_amt;
					}else if( busi_cmp_cfg.fund_sec_direction.charAt(0) == '0' ){
						tmp.dfirst_buy_amt += result.ddone_amt;
					}
				}else{
					if(result.sin_out.length()>0 && result.sin_out.charAt(0) == '1' ){
						tmp.dsecond_sell_amt += result.ddone_amt;
					}else if(result.sin_out.length()>0 && result.sin_out.charAt(0) == '0' ){
						tmp.dsecond_buy_amt += result.ddone_amt;
					}else if( busi_cmp_cfg.fund_sec_direction.charAt(0) == '1' ){
						tmp.dsecond_sell_amt += result.ddone_amt;
					}else if( busi_cmp_cfg.fund_sec_direction.charAt(0) == '0' ){
						tmp.dsecond_buy_amt += result.ddone_amt;
					}
				}
			}
			//����
			{
				if( busi_cmp_cfg.idata_source_type == 1 ){
					tmp.dfirst_stamp_tax += result.dstamp_tax;
					tmp.dfirst_chg_owner_fee += result.dchg_owner_fee;
				}else{
					tmp.dsecond_stamp_tax += result.dstamp_tax;
					tmp.dsecond_chg_owner_fee += result.dchg_owner_fee;
				}
			}
			
			result_set.add(tmp);
		}
		rSet.close();
		stmt.close();
	}
	
	public void compare( Vector<BUSI_CMP_RESULT> vres){
		boolean needStop = false;
		for( int i=0; i<vres.size(); i++ )
		//�Ƚϱȶ��ж�
		{
			BUSI_CMP_RESULT result = vres.get(i);
			if( result.dfirst_buy_amt == result.dsecond_buy_amt &&
					result.dfirst_buy_vol == result.dsecond_buy_vol &&
					result.dfirst_sell_amt == result.dsecond_sell_amt &&
					result.dfirst_sell_vol == result.dsecond_sell_vol &&
					result.dfirst_stamp_tax == result.dsecond_stamp_tax &&
					result.dfirst_chg_owner_fee == result.dsecond_chg_owner_fee){
				result.icmp_is_equal = 1;
				result.inequal_type = NEQUAL_TYPE.NEQUAL_TYPE_ALL_EQUAL.num();
				result.snequal_comment = NEQUAL_TYPE.NEQUAL_TYPE_ALL_EQUAL.str();
				System.out.print("[SEC_CODE]"+result.ssec_code+": ");
				System.out.println(result.snequal_comment);
			}else{
				result.icmp_is_equal = 2;
				needStop = true;
				if( result.dfirst_buy_amt == result.dsecond_buy_amt &&
						result.dfirst_buy_vol == result.dsecond_buy_vol &&
						result.dfirst_sell_amt == result.dsecond_sell_amt &&
						result.dfirst_sell_vol == result.dsecond_sell_vol )
				{
					result.inequal_type = NEQUAL_TYPE.NEQUAL_TYPE_NEARLY_EQUAL.num();
					result.snequal_comment = NEQUAL_TYPE.NEQUAL_TYPE_NEARLY_EQUAL.str();
					System.err.println("[SEC_CODE]"+result.ssec_code+": "+result.snequal_comment);
				}
				else if( result.dfirst_buy_vol ==  result.dsecond_buy_vol &&
						result.dfirst_sell_vol == result.dsecond_sell_vol )
				{
					result.inequal_type = NEQUAL_TYPE.NEQUAL_TYPE_AMT_NOT_EQUAL.num();
					result.snequal_comment = NEQUAL_TYPE.NEQUAL_TYPE_AMT_NOT_EQUAL.str();
					System.err.println("[SEC_CODE]"+result.ssec_code+": "+result.snequal_comment);
				}
				else if( result.dfirst_buy_amt == result.dsecond_buy_amt &&
						result.dfirst_sell_amt == result.dsecond_sell_amt )
				{
					result.inequal_type = NEQUAL_TYPE.NEQUAL_TYPE_VOL_NOT_EQUAL.num();
					result.snequal_comment = NEQUAL_TYPE.NEQUAL_TYPE_VOL_NOT_EQUAL.str();
					System.err.println("[SEC_CODE]"+result.ssec_code+": "+result.snequal_comment);
				}
				else {
					result.inequal_type = NEQUAL_TYPE.NEQUAL_TYPE_AMT_VOL_NOT_EQUAL.num();
					result.snequal_comment = NEQUAL_TYPE.NEQUAL_TYPE_AMT_VOL_NOT_EQUAL.str();
					System.err.println("[SEC_CODE]"+result.ssec_code+": "+result.snequal_comment);
				}
				
				if( needStop ){
					result.show();
				}
			}
		}
		
		if( needStop ){
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("���������������!...");
			Scanner in = new Scanner(System.in);
			String line = in.nextLine();
		}
	}
	
	public Vector<String> readConfig( String fileName ){
		Vector<String> vret = new Vector<String>();
		try{
			FileInputStream in = new FileInputStream(fileName);
			InputStreamReader inReader = new InputStreamReader(in);
			BufferedReader br = new BufferedReader(inReader);
			String line = null;
			while((line=br.readLine())!=null){
				vret.add(line.trim());
			}
			br.close();
			inReader.close();
			in.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return vret;
	}
	
	public void process(){
		
		conn = new DBConnect("jdbc:db2://10.10.14.36:50000/KSDBS:currentSchema=KS;", "back", "back");
		conn.connect();
		
		Vector<String> WorkDates = readConfig("work_date.txt");
		
		String sql1 = "SELECT MARKET_CODE, DONE_SEAT AS DONE_SEAT, '' AS BUSINESS_CODE, '' AS SEC_TYPE, SEC_CODE  ,'' AS IN_OUT  ,'' AS SEC_IN_OUT  ,VALUE(SUM(ABS(DONE_AMT)),0) AS DONE_AMT  ,VALUE(SUM(ABS(DONE_VOL)),0) AS DONE_VOL  ,0 AS STAMP_TAX_COL  ,0 AS CHG_OWNER_FEE  FROM KS.DONE_DETAIL  WHERE 1=1  AND DONE_DATE='20170502'  AND MARKET_CODE='2'  AND (CLR_CUST_NO='SJSJG')  AND (CUST_NAME='01DJBG-')  GROUP BY MARKET_CODE, DONE_SEAT, SEC_CODE  WITH UR FOR FETCH ONLY";
		String sql2 = "SELECT MARKET_CODE, SEAT_NO AS DONE_SEAT, BUSINESS_CODE, SEC_TYPE, SEC_CODE  ,'' AS IN_OUT  ,VALUE(SEC_IN_OUT, '') AS SEC_IN_OUT  ,VALUE(SUM(ABS(FUND_CHG)),0) AS DONE_AMT  ,VALUE(SUM(ABS(SEC_CHG)),0) AS DONE_VOL  ,0 AS STAMP_TAX_COL  ,0 AS CHG_OWNER_FEE  FROM KS.FUND_STK_CHG_FC  WHERE 1=1  AND OCCUR_DATE='20170502'  AND MARKET_CODE='2'  AND BUSINESS_CODE='4619'  GROUP BY MARKET_CODE, SEAT_NO, BUSINESS_CODE, SEC_TYPE, SEC_CODE  , SEC_IN_OUT  WITH UR FOR FETCH ONLY ";
		for( int i=0; i<WorkDates.size(); ++i ){
			result_set = new BUSI_CMP_RESULT_set();
			
			/*����BUSI_CMP_CFG*/
			{
				busi_cmp_cfg.market_code = "2";
				busi_cmp_cfg.sec_type = "";
				busi_cmp_cfg.business_code = "4619";
				busi_cmp_cfg.cmp_type = 1;
				busi_cmp_cfg.fund_sec_direction = "N1";
				busi_cmp_cfg.idata_source_type = 1;
			}
			try{
				
				String tsql = sql1.replace("#WORK_DATE#", WorkDates.get(i) );
				System.out.println(tsql);
				getResultSet(tsql);
				
				busi_cmp_cfg.idata_source_type = 2;
				tsql = sql2.replace("#WORK_DATE#", WorkDates.get(i) );
				System.out.println(tsql);
				getResultSet(tsql);
				
				compare(result_set.m_results);
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args) {
		PQDZServer server = new PQDZServer();
		server.process();
	}

}
