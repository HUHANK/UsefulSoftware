package PiQianDuiZhang;


public class BUSI_CMP_CFG {

	public String 	market_code 		= "";
	public String 	business_code 		= "";
	public String 	sec_type 			= "";
	public String 	fund_sec_direction 	= "";
	public int 		cmp_type 			= -1;
	public String 	in_out_col			 = "";
	public int 		idata_source_type	= -1;
	
}
