package PiQianDuiZhang;

import java.util.Vector;

public class BUSI_CMP_RESULT_set {

	public Vector<BUSI_CMP_RESULT>  m_results = null;
	
	public BUSI_CMP_RESULT_set(){
		m_results = new Vector<BUSI_CMP_RESULT>();
	}
	
	public BUSI_CMP_RESULT Find(BUSI_CMP_RESULT result){
		for( int i=0; i<m_results.size(); i++ ){
			BUSI_CMP_RESULT tmp = m_results.get(i);
			if( tmp.smarket_code.trim().equals( result.smarket_code.trim() ) )
				if( tmp.sseat_no.trim().equals( result.sseat_no.trim() ) )
					//if( tmp.sbusiness_code.trim().equals( result.sbusiness_code.trim() ) )
						if( tmp.ssec_code.trim().equals( result.ssec_code.trim() ) )
						{
							m_results.remove(i);
							return tmp;
						}
		}
		
		return BUSI_CMP_RESULT.dump(result);
	}
	
	public void add( BUSI_CMP_RESULT result ){
		m_results.add(result);
	}
	
}
