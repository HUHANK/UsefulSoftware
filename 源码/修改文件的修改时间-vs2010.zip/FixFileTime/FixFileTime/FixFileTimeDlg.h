
// FixFileTimeDlg.h : ͷ�ļ�
//

#pragma once
#include "atlcomtime.h"
#include "afxcmn.h"


// CFixFileTimeDlg �Ի���
class CFixFileTimeDlg : public CDialogEx
{
// ����
public:
	CFixFileTimeDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_FIXFILETIME_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	COleDateTime m_OleDate;
	COleDateTime m_OleTime;
	CString m_Path;
	CListCtrl m_ListCrtl;
	afx_msg void OnEnChangeMfceditbrowse();
	void BrowserFolders(CString sFilePath);
	afx_msg void OnNMDblclkList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedButtonSingle();
	virtual void OnCancel();
	afx_msg void OnBnClickedButtonCancle();
	afx_msg void OnBnClickedButtonAll();
};
